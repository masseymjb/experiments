# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 13:42:42 2016

@author: andy
"""

#! /usr/bin/env python

import csv
import itertools
import numpy as np
import time
import sys
import operator
import io
import array
from datetime import datetime

from irnn_theano_mnist784_bsgd_margin import RNNTheano

def onehoty(y):
    yclasses=len(set(y))
    ydim = len(y)
    z = np.zeros((ydim,yclasses))
    z[np.arange(ydim),y]=1
    return z

def test_model_acc(x_test,y_test,model):
    batchsize = model.batchsize
    flag = len(y_test)%batchsize
    batchnum = len(y_test)/batchsize
    if flag != 0 :
        batchnum +=1
        print 'watch out the last batch!'
    predic_class = np.zeros_like(y_test)
    for i in range(batchnum) :
        indexstart = i*batchsize
        predic_class[indexstart:(indexstart+batchsize)]=model.predict_class(x_test[indexstart:(indexstart+batchsize)])
    accu = np.equal(predic_class,y_test).mean() * 100.
    return accu

def train_with_sgd(model, X_train, y_train, learning_rate=None,decay=0.9):
    num_examples_seen = 0
    batchsize = model.batchsize
    flag = len(y_train)%batchsize
    batchnum = len(y_train)/batchsize
    if flag != 0 :
        batchnum +=1
        print 'watch out the last batch!'    
    sgdindex = np.random.permutation(len(y_train))
    for i in range(batchnum):
        indexstart = i*batchsize
        # One BSGD step
        model.bsgd_step(X_train[sgdindex[indexstart:(indexstart+batchsize)]],
                        y_train[sgdindex[indexstart:(indexstart+batchsize)]],
                        learning_rate, decay)
        num_examples_seen += batchsize
    return model



def save_model_parameters_theano(model, outfile):
    np.savez(outfile,
        U=model.U.get_value(),
        W=model.W.get_value(),
        V=model.V.get_value(),
        b=model.b.get_value(),
        c=model.c.get_value())
    print "Saved model parameters to %s." % outfile

def load_model_parameters_theano(path, modelClass=RNNTheano):
    npzfile = np.load(path)
    U, W, V, b, c = npzfile["U"], npzfile["W"], npzfile["V"], npzfile["b"], npzfile["c"]
    input_dim, hidden_dim, class_dim = U.shape[0], U.shape[1], V.shape[1]
    print "Building model model from %s with input_dim=%d hidden_dim=%d class_dim=%d" % (path, input_dim, hidden_dim, class_dim)
    sys.stdout.flush()
    model = modelClass(input_dim, class_dim, hidden_dim, margin_param=0.75)
    model.U.set_value(U)
    model.W.set_value(W)
    model.V.set_value(V)
    model.b.set_value(b)
    model.c.set_value(c)
    return model 

def gradient_check_theano(model, x, y, h=0.001, error_threshold=0.01):
    # Overwrite the bptt attribute. We need to backpropagate all the way to get the correct gradient
    model.bptt_truncate = 1000
    # Calculate the gradients using backprop
    bptt_gradients = model.bptt(x, y)
    # List of all parameters we want to chec.
    model_parameters = ['U', 'W', 'b', 'V', 'c']
    # Gradient check for each parameter
    for pidx, pname in enumerate(model_parameters):
        # Get the actual parameter value from the mode, e.g. model.W
        parameter_T = operator.attrgetter(pname)(model)
        parameter = parameter_T.get_value()
        print "Performing gradient check for parameter %s with size %d." % (pname, np.prod(parameter.shape))
        # Iterate over each element of the parameter matrix, e.g. (0,0), (0,1), ...
        it = np.nditer(parameter, flags=['multi_index'], op_flags=['readwrite'])
        while not it.finished:
            ix = it.multi_index
            # Save the original value so we can reset it later
            original_value = parameter[ix]
            # Estimate the gradient using (f(x+h) - f(x-h))/(2*h)
            parameter[ix] = original_value + h
            parameter_T.set_value(parameter)
            gradplus = model.calculate_total_loss([x],[y])
            parameter[ix] = original_value - h
            parameter_T.set_value(parameter)
            gradminus = model.calculate_total_loss([x],[y])
            estimated_gradient = (gradplus - gradminus)/(2*h)

            # The gradient for this parameter calculated using backpropagation
            backprop_gradient = bptt_gradients[pidx][ix]
            # calculate The relative error: (|x - y|/(|x| + |y|))
            relative_error = np.abs(backprop_gradient - estimated_gradient)/(np.abs(backprop_gradient) + np.abs(estimated_gradient))
            # If the error is to large fail the gradient check
            if relative_error > error_threshold:
                print "Gradient Check ERROR: parameter=%s ix=%s" % (pname, ix)
                print "+h Loss: %f" % gradplus
                print "-h Loss: %f" % gradminus
                print "Estimated_gradient: %f" % estimated_gradient
                print "Backpropagation gradient: %f" % backprop_gradient
                print "Relative Error: %f" % relative_error
                return 
            it.iternext()
        print "Gradient check for parameter %s passed." % (pname)
