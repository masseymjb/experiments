# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 13:31:12 2016

@author: andy
"""

#! /usr/bin/env python

import cPickle
import gzip

import sys
import os
import time

import numpy as np
np.random.seed(2016)

import theano

from datetime import datetime

from irnn_theano_mnist784_bsgd_margin import RNNTheano
from irnn_utils_mnist784_bsgd_margin import *


LEARNING_RATE = float(os.environ.get("LEARNING_RATE", "0.00000001"))
HIDDEN_DIM = int(os.environ.get("HIDDEN_DIM", "100"))
NEPOCH = int(os.environ.get("NEPOCH", "10000"))
BATCHSIZE = int(os.environ.get("BATCHSIZE", "16"))
MARGIN_PARAM = float(os.environ.get("MARGIN_PARAM", "0.25"))

#ts = datetime.now().strftime("%Y-%m-%d-%H-%M")
#MODEL_OUTPUT_FILE = "RNN-%s-%s.dat" % (ts, HIDDEN_DIM)


input_dim=1
class_dim=10
hidden_dim=HIDDEN_DIM
batchsize = BATCHSIZE

# Load data
datapath='./data/mnist.pkl.gz'

# load data directly
f = gzip.open(datapath, 'rb')
train_set, valid_set, test_set = cPickle.load(f)
f.close()
trainx,trainy=train_set
validx,validy=valid_set
testx,testy=test_set

# reshape x
trainxr = trainx.reshape((-1,784,1))
validxr = validx.reshape((-1,784,1))
testxr = testx.reshape((-1,784,1))

# convert y to one hot vector
trainyc = onehoty(trainy).astype('int64')
validyc = onehoty(validy).astype('int64')
testyc = onehoty(testy).astype('int64')



# Build model
model = RNNTheano(input_dim, class_dim, hidden_dim, batchsize, bptt_truncate=-1, margin_param = MARGIN_PARAM)

# load model
#model = load_model_parameters_theano('IRNN-bsgd-2016-06-28-05-59-accvalid95.91-epoch199.npz')

# Print SGD step time
t1 = time.time()
model.bsgd_step(trainxr[0:batchsize], trainyc[0:batchsize], LEARNING_RATE, 0.9)
t2 = time.time()
print "BSGD Step time: %f milliseconds" % ((t2 - t1) * 1000.)
sys.stdout.flush()

accutrain=[]
accuvalid=[]
accutest =[]
tstart = time.time()
for epoch in range(NEPOCH):
    train_with_sgd(model, trainxr, trainyc, learning_rate=LEARNING_RATE, decay=0.9)

    accutrain.append(test_model_acc(trainxr,trainy,model))
    accuvalid.append(test_model_acc(validxr,validy,model))
    accutest.append(test_model_acc(testxr,testy,model))

    cbtime = time.time()
    print "BSGD training time: %f minutes \n" % ((cbtime - tstart)/60.0)
    print 'epoch:{0},train accuracy:{1}, valid accuracy:{2}, test accuracy:{3}'.format(epoch,accutrain[-1],accuvalid[-1],accutest[-1])
    print("--------------------------------------------------")
    sys.stdout.flush()
    if epoch%100 == 0:
        ts = datetime.now().strftime("%Y%m%d-%H%M")
        MODEL_OUTPUT_FILE = "IRNN-%s-epoch%s" % (ts,epoch)
        save_model_parameters_theano(model, MODEL_OUTPUT_FILE)
        ACC_FILE = 'IRNN-bsgd784-{ts}-m{m:.2f}'.format(ts =ts, m=MARGIN_PARAM)
        results = [accutrain,accuvalid,accutest]
        cPickle.dump(results,open(ACC_FILE,'wb'))


