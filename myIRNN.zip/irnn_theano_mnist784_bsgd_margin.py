# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 10:54:20 2016

@author: andy
"""

import numpy as np
import theano as theano
import theano.tensor as T
from theano.gradient import grad_clip
import time
import operator

class RNNTheano:
    
    def __init__(self, input_dim, class_dim, hidden_dim, batchsize=16, bptt_truncate=-1, margin_param=0.75):
        # Assign instance variables
        self.input_dim = input_dim
        self.class_dim = class_dim
        self.hidden_dim = hidden_dim
        self.batchsize = batchsize
        self.bptt_truncate = bptt_truncate
        self.margin_param = margin_param
        # Initialize the network parameters
        U = np.random.normal(0, 0.001, (input_dim, hidden_dim))
        W = np.identity(hidden_dim)
        V = np.random.normal(0, 0.001, (hidden_dim,class_dim))
        b = np.zeros(hidden_dim)
        c = np.random.normal(0, 0.001, class_dim)
        # Theano: Created shared variables
        self.U = theano.shared(name='U', value=U.astype(theano.config.floatX))
        self.W = theano.shared(name='W', value=W.astype(theano.config.floatX))
        self.V = theano.shared(name='V', value=V.astype(theano.config.floatX))
        self.b = theano.shared(name='b', value=b.astype(theano.config.floatX))
        self.c = theano.shared(name='c', value=c.astype(theano.config.floatX))
        # SGD / rmsprop: Initialize parameters
        self.mU = theano.shared(name='mU', value=np.zeros(U.shape).astype(theano.config.floatX))
        self.mV = theano.shared(name='mV', value=np.zeros(V.shape).astype(theano.config.floatX))
        self.mW = theano.shared(name='mW', value=np.zeros(W.shape).astype(theano.config.floatX))
        self.mb = theano.shared(name='mb', value=np.zeros(b.shape).astype(theano.config.floatX))
        self.mc = theano.shared(name='mc', value=np.zeros(c.shape).astype(theano.config.floatX))
        # We store the Theano graph here
        self.theano = {}
        self.__theano_build__()
        
    def __theano_build__(self):
        U, V, W, b, c = self.U, self.V, self.W, self.b, self.c

#        x = T.dvector('x')
#        y = T.lvector('y')
        X=T.dtensor3('X')
        Y=T.lmatrix('Y')
        
        def numpy_floatX(data):
            return np.asarray(data, dtype=theano.config.floatX)
        
        
        def forward_prop_step(x_e, s_t1_prev):
            # x_e has the dim (batchsize, input_dim),
            # s_t1 has the dim (batchsize, hidden_dim)
            s_t1 = T.nnet.relu(T.dot(x_e,U) + T.dot(s_t1_prev,W) + b)
            # o_t has the dim (batchsize, class_dim)
            o_t = T.nnet.softmax(T.dot(s_t1,V) + c)
            return [o_t, s_t1]
        
        
        [o, s], updates = theano.scan(
            forward_prop_step,
            sequences=X.dimshuffle(1,0,2),
            truncate_gradient=-1,
            outputs_info=[None,T.alloc(numpy_floatX(0.), self.batchsize, self.hidden_dim)]
            )
        
        # o[-1] has the dim (batchsize, class_dim), so the argmax axis is 1          
        prediction = T.argmax(o[-1], axis=1)
        o_error = T.sum(T.nnet.categorical_crossentropy(o[-1], Y))
#        
        # margin term
        margin_term = T.sum((T.max(((1-Y) * o[-1]),axis=1) - T.max(Y*o[-1], axis = 1)))
        
        # Total cost (could add regularization here)
        cost = o_error + self.margin_param * margin_term
        
        # Gradients
        dU = T.grad(grad_clip(cost,-1,1), U)
        dW = T.grad(grad_clip(cost,-1,1), W)
        db = T.grad(grad_clip(cost,-1,1), b)
        dV = T.grad(grad_clip(cost,-1,1), V)
        dc = T.grad(grad_clip(cost,-1,1), c)
        # Assign functions
        self.predict = theano.function([X], o[-1])
        self.predict_class = theano.function([X], prediction)
        self.ce_error = theano.function([X, Y], cost)
        self.bptt = theano.function([X, Y], [dU, dW, db, dV, dc])
        
        # SGD parameters
        learning_rate = T.scalar('learning_rate')
        decay = T.scalar('decay')
        
        # rmsprop cache updates
        mU = decay * self.mU + learning_rate * dU
        mW = decay * self.mW + learning_rate * dW
        mV = decay * self.mV + learning_rate * dV
        mb = decay * self.mb + learning_rate * db
        mc = decay * self.mc + learning_rate * dc
        
        self.bsgd_step = theano.function(
            [X, Y, learning_rate, decay],
            [], 
            updates=[(U, U - mU),
                     (W, W - mW),
                     (V, V - mV),
                     (b, b - mb),
                     (c, c - mc),
                     (self.mU, mU),
                     (self.mW, mW),
                     (self.mV, mV),
                     (self.mb, mb),
                     (self.mc, mc)
                    ])

        
        
#    def calculate_total_loss(self, X, Y):
#        return np.sum([self.ce_error(x,y) for x,y in zip(X,Y)])
    
    def calculate_loss(self, X, Y):
        # Divide calculate_loss by the number of words
        num_samples = X.shape[0]
        return self.ce_error(X,Y)/float(num_samples)
        
    def get_batchsize(self):
        return self.batchsize
